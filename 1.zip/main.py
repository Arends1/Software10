﻿from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.core.configuracion import configuracion
from app.modelos.base_datos import crear_tablas

app = FastAPI(title='El Unificador - Constrefri')

# Configurar CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=configuracion.ORIGENES_PERMITIDOS,
    allow_credentials=True,
    allow_methods=['*'],
    allow_headers=['*'],
)

@app.on_event('startup')
def iniciar():
    crear_tablas()
    print('Tablas de la base de datos creadas')

@app.get('/')
def leer_raiz():
    return {'mensaje': 'Bienvenido a El Unificador - API de Constrefri'}

@app.get('/salud')
def verificar_salud():
    return {'estado': 'saludable', 'servicio': 'el-unificador-backend'}

if __name__ == '__main__':
    import uvicorn
    uvicorn.run('main:app', host='0.0.0.0', port=8000, reload=True)
