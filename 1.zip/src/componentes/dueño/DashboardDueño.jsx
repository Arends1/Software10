import React, { useState } from 'react';
import GestionUsuarios from '../administrador/GestionUsuarios';
import ConfiguracionSistema from '../administrador/ConfiguracionSistema';
import AuditoriaCompleta from '../administrador/AuditoriaCompleta';
import ReportesAvanzados from '../administrador/ReportesAvanzados';
import CierreDiario from '../empleado/CierreDiario';
import ConsultaInventario from '../empleado/ConsultaInventario';
import AjustesStock from '../empleado/AjustesStock';
import RevertirProcesos from './RevertirProcesos';

const DashboardDueño = () => {
  const [seccionActiva, setSeccionActiva] = useState('inicio');

  // Datos ejecutivos para el dueño
  const metricasEjecutivas = {
    ventasMes: 24500,
    gananciaNeta: 8200,
    crecimientoAnual: 15.8,
    rentabilidad: 33.5,
    clientesNuevos: 28,
    satisfaccionClientes: 4.7
  };

  const renderizarSeccion = () => {
    switch(seccionActiva) {
      case 'gestion-usuarios':
        return <GestionUsuarios />;
      case 'configuracion-sistema':
        return <ConfiguracionSistema />;
      case 'auditoria':
        return <AuditoriaCompleta />;
      case 'reportes-avanzados':
        return <ReportesAvanzados />;
      case 'cierre-diario':
        return <CierreDiario />;
      case 'consulta-inventario':
        return <ConsultaInventario />;
      case 'ajustes-stock':
        return <AjustesStock />;
      case 'revertir-procesos':
        return <RevertirProcesos />;
      default:
        return (
          <div className="space-y-6">
            {/* Header del Dashboard */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h1 className="text-2xl font-bold text-gray-800">Dashboard Ejecutivo - Dueño</h1>
              <p className="text-gray-600">Vision completa y control total de Constrefri</p>
            </div>

            {/* Metricas Ejecutivas */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-500">
                <h3 className="text-sm font-medium text-gray-500">Ventas del Mes</h3>
                <p className="text-2xl font-bold text-gray-800">${metricasEjecutivas.ventasMes}</p>
                <span className="text-xs text-green-500">+{metricasEjecutivas.crecimientoAnual}% anual</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-500">
                <h3 className="text-sm font-medium text-gray-500">Ganancia Neta</h3>
                <p className="text-2xl font-bold text-gray-800">${metricasEjecutivas.gananciaNeta}</p>
                <span className="text-xs text-green-500">{metricasEjecutivas.rentabilidad}% rentabilidad</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-purple-500">
                <h3 className="text-sm font-medium text-gray-500">Satisfaccion Clientes</h3>
                <p className="text-2xl font-bold text-gray-800">{metricasEjecutivas.satisfaccionClientes}/5</p>
                <span className="text-xs text-green-500">Excelente</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-yellow-500">
                <h3 className="text-sm font-medium text-gray-500">Clientes Nuevos</h3>
                <p className="text-2xl font-bold text-gray-800">{metricasEjecutivas.clientesNuevos}</p>
                <span className="text-xs text-blue-500">Este mes</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-red-500">
                <h3 className="text-sm font-medium text-gray-500">Eficiencia Operativa</h3>
                <p className="text-2xl font-bold text-gray-800">94%</p>
                <span className="text-xs text-green-500">+5% vs mes anterior</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-indigo-500">
                <h3 className="text-sm font-medium text-gray-500">Inventario Valorizado</h3>
                <p className="text-2xl font-bold text-gray-800">$185,000</p>
                <span className="text-xs text-gray-500">Stock total</span>
              </div>
            </div>

            {/* Acciones Ejecutivas */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Control del Sistema */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Control del Sistema</h3>
                <div className="grid grid-cols-1 gap-3">
                  <button 
                    onClick={() => setSeccionActiva('configuracion-sistema')}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Configurar Sistema
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('gestion-usuarios')}
                    className="w-full bg-green-500 hover:bg-green-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Gestionar Usuarios
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('auditoria')}
                    className="w-full bg-yellow-500 hover:bg-yellow-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Auditoria Completa
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('revertir-procesos')}
                    className="w-full bg-red-500 hover:bg-red-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Revertir Procesos
                  </button>
                </div>
              </div>

              {/* Operaciones y Analisis */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Operaciones y Analisis</h3>
                <div className="grid grid-cols-1 gap-3">
                  <button 
                    onClick={() => setSeccionActiva('reportes-avanzados')}
                    className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Reportes Ejecutivos
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('cierre-diario')}
                    className="w-full bg-indigo-500 hover:bg-indigo-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Realizar Cierre Diario
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('consulta-inventario')}
                    className="w-full bg-teal-500 hover:bg-teal-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Consultar Inventario
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('ajustes-stock')}
                    className="w-full bg-orange-500 hover:bg-orange-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Ajustes de Stock
                  </button>
                </div>
              </div>
            </div>

            {/* KPIs Ejecutivos */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Indicadores Clave (KPIs)</h3>
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="text-center p-4 bg-blue-50 rounded-lg">
                  <p className="text-2xl font-bold text-blue-600">15.8%</p>
                  <p className="text-sm text-blue-700">Crecimiento Anual</p>
                </div>
                <div className="text-center p-4 bg-green-50 rounded-lg">
                  <p className="text-2xl font-bold text-green-600">33.5%</p>
                  <p className="text-sm text-green-700">Margen de Ganancia</p>
                </div>
                <div className="text-center p-4 bg-purple-50 rounded-lg">
                  <p className="text-2xl font-bold text-purple-600">2.8x</p>
                  <p className="text-sm text-purple-700">Rotacion Inventario</p>
                </div>
                <div className="text-center p-4 bg-yellow-50 rounded-lg">
                  <p className="text-2xl font-bold text-yellow-600">94%</p>
                  <p className="text-sm text-yellow-700">Eficiencia Operativa</p>
                </div>
              </div>
            </div>

            {/* Alertas Ejecutivas */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Alertas Ejecutivas</h3>
              <div className="space-y-3">
                <div className="p-4 bg-green-50 rounded-lg border border-green-200">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">Meta de Ventas Superada</span>
                    <span className="text-green-600 font-bold">+12%</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Las ventas del mes superaron la proyeccion en $2,600</p>
                </div>
                
                <div className="p-4 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">Oportunidad de Expansion</span>
                    <span className="text-yellow-600 font-bold">Analizar</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Aumento del 28% en demanda de materiales de construccion</p>
                </div>
                
                <div className="p-4 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">Revision de Proveedores</span>
                    <span className="text-blue-600 font-bold">Programado</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Reunion trimestral con proveedores principales la proxima semana</p>
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {seccionActiva !== 'inicio' && (
        <button 
          onClick={() => setSeccionActiva('inicio')}
          className="mb-4 flex items-center text-blue-600 hover:text-blue-800 transition duration-200"
        >
          ← Volver al Dashboard Ejecutivo
        </button>
      )}
      {renderizarSeccion()}
    </div>
  );
};

export default DashboardDueño;