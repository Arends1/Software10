import React, { useState } from 'react';

const RevertirProcesos = () => {
  const [procesoSeleccionado, setProcesoSeleccionado] = useState('');
  const [confirmando, setConfirmando] = useState(false);
  const [procesoRevertido, setProcesoRevertido] = useState(false);

  // Procesos que se pueden revertir
  const procesos = [
    { 
      id: 1, 
      tipo: 'cierre-diario', 
      descripcion: 'Cierre Diario - 15/01/2024', 
      fecha: '2024-01-15 14:30:25',
      usuario: 'Maria Gonzalez',
      detalles: 'Ventas: $850, 15 productos procesados',
      impacto: 'Eliminara el registro de ventas y restablecera el inventario'
    },
    { 
      id: 2, 
      tipo: 'ajuste-stock', 
      descripcion: 'Ajuste de Stock - Cemento 50kg', 
      fecha: '2024-01-15 13:15:10',
      usuario: 'Juan Perez',
      detalles: 'Merma: -2 unidades, Motivo: Daño',
      impacto: 'Restablecera el stock anterior de cemento'
    },
    { 
      id: 3, 
      tipo: 'creacion-usuario', 
      descripcion: 'Creacion de Usuario - Luis Mendoza', 
      fecha: '2024-01-14 16:45:30',
      usuario: 'Carlos Ruiz',
      detalles: 'Nuevo usuario empleado creado',
      impacto: 'Desactivara el usuario y eliminara permisos'
    },
    { 
      id: 4, 
      tipo: 'configuracion', 
      descripcion: 'Cambio Configuracion Stock', 
      fecha: '2024-01-13 11:20:15',
      usuario: 'Ana Torres',
      detalles: 'Alerta stock bajo cambiada de 10 a 8 unidades',
      impacto: 'Restablecera la configuracion anterior'
    }
  ];

  const procesoActual = procesos.find(p => p.id === parseInt(procesoSeleccionado));

  const manejarRevertir = async () => {
    setConfirmando(true);
    
    // Simular proceso de reversion
    await new Promise(resolve => setTimeout(resolve, 3000));
    
    setProcesoRevertido(true);
    setConfirmando(false);
    setProcesoSeleccionado('');
  };

  const obtenerColorTipo = (tipo) => {
    switch(tipo) {
      case 'cierre-diario': return 'bg-red-100 text-red-800';
      case 'ajuste-stock': return 'bg-yellow-100 text-yellow-800';
      case 'creacion-usuario': return 'bg-blue-100 text-blue-800';
      case 'configuracion': return 'bg-purple-100 text-purple-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const obtenerTextoConfirmacion = (tipo) => {
    switch(tipo) {
      case 'cierre-diario': return 'revertir el cierre diario';
      case 'ajuste-stock': return 'revertir el ajuste de stock';
      case 'creacion-usuario': return 'desactivar el usuario';
      case 'configuracion': return 'revertir la configuracion';
      default: return 'revertir el proceso';
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Revertir Procesos</h2>
        <p className="text-gray-600 mb-6">Funcion avanzada para revertir acciones del sistema (Solo Dueño)</p>

        {procesoRevertido && (
          <div className="bg-green-50 border border-green-200 rounded-lg p-4 mb-6">
            <h3 className="text-lg font-semibold text-green-800 mb-2">Proceso Revertido Exitosamente</h3>
            <p className="text-green-700">El proceso ha sido revertido y el sistema ha sido restablecido.</p>
            <button
              onClick={() => setProcesoRevertido(false)}
              className="mt-3 bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200"
            >
              Revertir Otro Proceso
            </button>
          </div>
        )}

        {!procesoRevertido && (
          <div className="space-y-6">
            {/* Seleccion de Proceso */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Seleccionar Proceso a Revertir
              </label>
              <select
                value={procesoSeleccionado}
                onChange={(e) => setProcesoSeleccionado(e.target.value)}
                className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="">Seleccionar proceso...</option>
                {procesos.map(proceso => (
                  <option key={proceso.id} value={proceso.id}>
                    {proceso.descripcion} - {proceso.fecha}
                  </option>
                ))}
              </select>
            </div>

            {/* Informacion del Proceso Seleccionado */}
            {procesoActual && (
              <div className="bg-gray-50 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Detalles del Proceso</h3>
                
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                  <div>
                    <p className="text-sm font-medium text-gray-700">Tipo de Proceso</p>
                    <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${obtenerColorTipo(procesoActual.tipo)}`}>
                      {procesoActual.tipo}
                    </span>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700">Usuario</p>
                    <p className="text-sm text-gray-900">{procesoActual.usuario}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700">Fecha y Hora</p>
                    <p className="text-sm text-gray-900">{procesoActual.fecha}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-gray-700">Estado</p>
                    <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      Completado
                    </span>
                  </div>
                </div>

                <div className="mb-4">
                  <p className="text-sm font-medium text-gray-700">Detalles</p>
                  <p className="text-sm text-gray-900">{procesoActual.detalles}</p>
                </div>

                <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                  <p className="text-sm font-medium text-yellow-800 mb-2">Impacto de la Reversion</p>
                  <p className="text-sm text-yellow-700">{procesoActual.impacto}</p>
                </div>

                {/* Confirmacion */}
                {!confirmando ? (
                  <div className="mt-6 flex space-x-4">
                    <button
                      onClick={manejarRevertir}
                      className="bg-red-500 hover:bg-red-600 text-white px-6 py-3 rounded-lg font-semibold transition duration-200"
                    >
                      Confirmar Reversion
                    </button>
                    <button
                      onClick={() => setProcesoSeleccionado('')}
                      className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-medium transition duration-200"
                    >
                      Cancelar
                    </button>
                  </div>
                ) : (
                  <div className="mt-6 bg-blue-50 rounded-lg p-4">
                    <div className="flex items-center justify-center">
                      <div className="w-6 h-6 border-t-2 border-blue-600 border-solid rounded-full animate-spin mr-3"></div>
                      <p className="text-blue-700 font-medium">
                        Revertiendo proceso: {obtenerTextoConfirmacion(procesoActual.tipo)}...
                      </p>
                    </div>
                    <p className="text-sm text-blue-600 mt-2 text-center">
                      Esta operacion puede tomar algunos segundos
                    </p>
                  </div>
                )}
              </div>
            )}

            {/* Informacion de Seguridad */}
            <div className="bg-red-50 border border-red-200 rounded-lg p-4">
              <h3 className="font-semibold text-red-800 mb-2">Advertencia de Seguridad</h3>
              <ul className="text-sm text-red-700 space-y-1">
                <li>• Esta funcion es solo para uso del dueño</li>
                <li>• La reversion de procesos no se puede deshacer</li>
                <li>• Se creara un registro permanente en la auditoria</li>
                <li>• Asegurese de comprender el impacto antes de proceder</li>
                <li>• Se recomienda hacer backup antes de operaciones criticas</li>
              </ul>
            </div>

            {/* Historial de Reversiones */}
            <div className="bg-white border rounded-lg p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Ultimas Reversiones</h3>
              <div className="space-y-3">
                {[
                  { proceso: 'Cierre Diario - 10/01/2024', fecha: '2024-01-11 09:15:00', usuario: 'Dueño' },
                  { proceso: 'Ajuste Stock - Tornillos', fecha: '2024-01-08 14:20:00', usuario: 'Dueño' }
                ].map((reversion, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-800">{reversion.proceso}</p>
                      <p className="text-xs text-gray-600">Por: {reversion.usuario}</p>
                    </div>
                    <span className="text-sm text-gray-500">{reversion.fecha}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default RevertirProcesos;