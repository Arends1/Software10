import React, { useState } from 'react';

const ReportesAvanzados = () => {
  const [reporteSeleccionado, setReporteSeleccionado] = useState('rendimiento');
  const [fechaInicio, setFechaInicio] = useState('2024-01-01');
  const [fechaFin, setFechaFin] = useState('2024-01-15');
  const [mostrarGraficos, setMostrarGraficos] = useState(false);

  // Datos reales para empresa pequeña
  const datosVentas = [
    { fecha: '01/11', ventas: 920 },
    { fecha: '02/11', ventas: 780 },
    { fecha: '03/11', ventas: 850 },
    { fecha: '04/11', ventas: 950 },
    { fecha: '05/11', ventas: 820 },
    { fecha: '06/11', ventas: 880 },
    { fecha: '07/11', ventas: 850 }
  ];

  const productosMasVendidos = [
    { producto: 'Cemento 50kg', vendidos: 12, ingresos: 2400 },
    { producto: 'Varilla 1/2"', vendidos: 8, ingresos: 1200 },
    { producto: 'Tornillos 3"', vendidos: 45, ingresos: 450 },
    { producto: 'Ladrillo 6h', vendidos: 120, ingresos: 1800 },
    { producto: 'Pintura Blanca', vendidos: 6, ingresos: 420 }
  ];

  const stockCritico = [
    { producto: 'Cemento 50kg', stock: 3, minimo: 10, estado: 'Critico' },
    { producto: 'Pegamento PVC', stock: 2, minimo: 5, estado: 'Critico' },
    { producto: 'Brocha 4"', stock: 6, minimo: 10, estado: 'Bajo' }
  ];

  const datosRendimiento = {
    ventasTotales: 24500,
    crecimiento: 8.5,
    productosVendidos: 450,
    clientesAtendidos: 120
  };

  const calcularTotalVentas = () => {
    return datosVentas.reduce((total, dia) => total + dia.ventas, 0);
  };

  const renderizarReporte = () => {
    switch(reporteSeleccionado) {
      case 'rendimiento':
        return (
          <div className="space-y-6">
            {/* Resumen de Ventas */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
              <div className="bg-white rounded-lg p-4 text-center border">
                <p className="text-2xl font-bold text-blue-600">${calcularTotalVentas()}</p>
                <p className="text-sm text-gray-600">Total Ventas</p>
              </div>
              <div className="bg-white rounded-lg p-4 text-center border">
                <p className="text-2xl font-bold text-green-600">{datosVentas.length}</p>
                <p className="text-sm text-gray-600">Dias Analizados</p>
              </div>
              <div className="bg-white rounded-lg p-4 text-center border">
                <p className="text-2xl font-bold text-purple-600">${Math.round(calcularTotalVentas() / datosVentas.length)}</p>
                <p className="text-sm text-gray-600">Promedio Diario</p>
              </div>
            </div>

            {/* Gráfico Simple de Ventas */}
            <div className="bg-white rounded-lg p-6 border">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Ventas de los Ultimos 7 Dias</h3>
              <div className="space-y-2">
                {datosVentas.map((dia, index) => (
                  <div key={index} className="flex items-center space-x-4">
                    <span className="w-16 text-sm text-gray-600">{dia.fecha}</span>
                    <div className="flex-1 bg-gray-200 rounded-full h-6">
                      <div 
                        className="bg-blue-500 h-6 rounded-full transition-all duration-500"
                        style={{ width: `${(dia.ventas / 1000) * 100}%` }}
                      ></div>
                    </div>
                    <span className="w-20 text-sm font-medium text-gray-800">${dia.ventas}</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Productos Mas Vendidos */}
            <div className="bg-white rounded-lg p-6 border">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Productos Mas Vendidos</h3>
              <div className="overflow-x-auto">
                <table className="min-w-full divide-y divide-gray-200">
                  <thead className="bg-gray-50">
                    <tr>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Producto</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Unidades</th>
                      <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Ingresos</th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {productosMasVendidos.map((producto, index) => (
                      <tr key={index}>
                        <td className="px-4 py-2 text-sm font-medium text-gray-900">{producto.producto}</td>
                        <td className="px-4 py-2 text-sm text-gray-500">{producto.vendidos}</td>
                        <td className="px-4 py-2 text-sm font-semibold text-green-600">${producto.ingresos}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        );

      case 'inventario':
        return (
          <div className="space-y-6">
            {/* Alertas de Stock */}
            <div className="bg-white rounded-lg p-6 border">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Productos con Stock Critico</h3>
              <div className="space-y-3">
                {stockCritico.map((producto, index) => (
                  <div key={index} className={`p-4 rounded-lg border ${
                    producto.estado === 'Critico' ? 'bg-red-50 border-red-200' : 'bg-yellow-50 border-yellow-200'
                  }`}>
                    <div className="flex justify-between items-center">
                      <span className="font-medium text-gray-800">{producto.producto}</span>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        producto.estado === 'Critico' ? 'bg-red-100 text-red-800' : 'bg-yellow-100 text-yellow-800'
                      }`}>
                        {producto.estado}
                      </span>
                    </div>
                    <div className="text-sm text-gray-600 mt-1">
                      Stock actual: <strong>{producto.stock}</strong> | Minimo requerido: <strong>{producto.minimo}</strong>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Resumen Stock */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div className="bg-white rounded-lg p-4 text-center border">
                <p className="text-2xl font-bold text-red-600">
                  {stockCritico.filter(p => p.estado === 'Critico').length}
                </p>
                <p className="text-sm text-gray-600">Productos Criticos</p>
              </div>
              <div className="bg-white rounded-lg p-4 text-center border">
                <p className="text-2xl font-bold text-yellow-600">
                  {stockCritico.filter(p => p.estado === 'Bajo').length}
                </p>
                <p className="text-sm text-gray-600">Productos con Stock Bajo</p>
              </div>
            </div>
          </div>
        );

      case 'usuarios':
        return (
          <div className="bg-white rounded-lg p-6 border">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Ultimos Cierres Procesados</h3>
            <div className="space-y-4">
              {[
                { fecha: '07/11/2023', ventas: 850, productos: 15, estado: 'Completado' },
                { fecha: '06/11/2023', ventas: 880, productos: 16, estado: 'Completado' },
                { fecha: '05/11/2023', ventas: 820, productos: 14, estado: 'Completado' },
                { fecha: '04/11/2023', ventas: 950, productos: 18, estado: 'Completado' }
              ].map((cierre, index) => (
                <div key={index} className="flex justify-between items-center p-4 bg-gray-50 rounded-lg">
                  <div>
                    <p className="font-medium text-gray-800">{cierre.fecha}</p>
                    <p className="text-sm text-gray-600">{cierre.productos} productos procesados</p>
                  </div>
                  <div className="text-right">
                    <p className="font-bold text-green-600">${cierre.ventas}</p>
                    <span className="inline-flex items-center px-2 py-1 rounded-full text-xs font-medium bg-green-100 text-green-800">
                      {cierre.estado}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Reportes Avanzados</h2>
        <p className="text-gray-600 mb-6">Informes y analisis del sistema</p>

        {/* Navegacion de Reportes */}
        <div className="flex space-x-1 bg-gray-100 p-1 rounded-lg mb-6">
          {[
            { id: 'rendimiento', nombre: 'Ventas' },
            { id: 'inventario', nombre: 'Stock' },
            { id: 'usuarios', nombre: 'Movimientos' }
          ].map((reporte) => (
            <button
              key={reporte.id}
              onClick={() => setReporteSeleccionado(reporte.id)}
              className={`flex-1 py-2 px-4 rounded-md text-sm font-medium transition duration-200 ${
                reporteSeleccionado === reporte.id
                  ? 'bg-white text-blue-600 shadow-sm'
                  : 'text-gray-600 hover:text-gray-800'
              }`}
            >
              {reporte.nombre}
            </button>
          ))}
        </div>

        {/* Filtros */}
        <div className="flex space-x-4 mb-6">
          <select
            value={fechaInicio}
            onChange={(e) => setFechaInicio(e.target.value)}
            className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="7dias">Ultimos 7 dias</option>
            <option value="30dias">Ultimos 30 dias</option>
            <option value="mes">Este mes</option>
          </select>
        </div>

        {/* Contenido del Reporte */}
        {renderizarReporte()}

        {/* Botones de Exportacion y Graficos */}
        <div className="mt-6 flex space-x-4">
          <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200">
            Exportar a PDF
          </button>
          <button className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200">
            Exportar a Excel
          </button>
          <button 
            onClick={() => setMostrarGraficos(!mostrarGraficos)}
            className="bg-purple-500 hover:bg-purple-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200"
          >
            {mostrarGraficos ? 'Ocultar Graficos' : 'Generar Graficos'}
          </button>
        </div>

        {/* Vista Previa de Graficos */}
        {mostrarGraficos && (
          <div className="mt-6 bg-white border rounded-lg p-6">
            <h3 className="text-lg font-semibold text-gray-800 mb-4">Dashboard de Graficos Ejecutivos</h3>
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              
              {/* Grafico de Barras - Ventas por Dia */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-800 mb-3">Ventas Diarias (Ultimas 2 Semanas)</h4>
                <div className="space-y-2">
                  {[
                    { fecha: '01/11', ventas: 920 },
                    { fecha: '02/11', ventas: 780 },
                    { fecha: '03/11', ventas: 850 },
                    { fecha: '04/11', ventas: 950 },
                    { fecha: '05/11', ventas: 820 },
                    { fecha: '06/11', ventas: 880 },
                    { fecha: '07/11', ventas: 850 },
                    { fecha: '08/11', ventas: 910 },
                    { fecha: '09/11', ventas: 790 },
                    { fecha: '10/11', ventas: 980 },
                    { fecha: '11/11', ventas: 870 },
                    { fecha: '12/11', ventas: 930 },
                    { fecha: '13/11', ventas: 810 },
                    { fecha: '14/11', ventas: 890 }
                  ].map((dia, index) => (
                    <div key={index} className="flex items-center space-x-3">
                      <span className="w-12 text-xs text-gray-600">{dia.fecha}</span>
                      <div className="flex-1 bg-gray-200 rounded-full h-4">
                        <div 
                          className="bg-green-500 h-4 rounded-full flex items-center justify-end pr-2 text-xs text-white font-medium transition-all duration-500"
                          style={{ width: `${(dia.ventas / 1000) * 100}%` }}
                        >
                          ${dia.ventas}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grafico de Torta - Distribucion de Ventas por Producto */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-800 mb-3">Distribucion de Ventas por Categoria</h4>
                <div className="space-y-3">
                  {[
                    { categoria: 'Materiales', ventas: 12500, porcentaje: 51, color: 'bg-blue-500' },
                    { categoria: 'Fijaciones', ventas: 4800, porcentaje: 20, color: 'bg-green-500' },
                    { categoria: 'Acabados', ventas: 4200, porcentaje: 17, color: 'bg-yellow-500' },
                    { categoria: 'Herramientas', ventas: 1800, porcentaje: 7, color: 'bg-red-500' },
                    { categoria: 'Otros', ventas: 1200, porcentaje: 5, color: 'bg-purple-500' }
                  ].map((item, index) => (
                    <div key={index} className="flex items-center justify-between">
                      <div className="flex items-center space-x-3">
                        <div className={`w-3 h-3 rounded-full ${item.color}`}></div>
                        <span className="text-sm text-gray-700">{item.categoria}</span>
                      </div>
                      <div className="flex items-center space-x-2">
                        <div className="w-24 bg-gray-200 rounded-full h-2">
                          <div 
                            className={`h-2 rounded-full ${item.color} transition-all duration-500`}
                            style={{ width: `${item.porcentaje}%` }}
                          ></div>
                        </div>
                        <span className="text-xs text-gray-600 w-12 text-right">{item.porcentaje}%</span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grafico de Lineas - Tendencia Mensual Mejorado */}
              <div className="bg-gray-50 rounded-lg p-4 lg:col-span-2">
                <h4 className="font-medium text-gray-800 mb-3">Tendencia de Ventas Mensual (Ultimo Año)</h4>
                <div className="flex items-end justify-between h-40 px-4 border-b border-l border-gray-300 space-x-2">
                  {[
                    { mes: 'Ene', ventas: 18500, crecimiento: 2 },
                    { mes: 'Feb', ventas: 19200, crecimiento: 4 },
                    { mes: 'Mar', ventas: 21000, crecimiento: 9 },
                    { mes: 'Abr', ventas: 19800, crecimiento: -6 },
                    { mes: 'May', ventas: 21500, crecimiento: 9 },
                    { mes: 'Jun', ventas: 22800, crecimiento: 6 },
                    { mes: 'Jul', ventas: 23500, crecimiento: 3 },
                    { mes: 'Ago', ventas: 24200, crecimiento: 3 },
                    { mes: 'Sep', ventas: 23800, crecimiento: -2 },
                    { mes: 'Oct', ventas: 24500, crecimiento: 3 },
                    { mes: 'Nov', ventas: 25200, crecimiento: 3 },
                    { mes: 'Dic', ventas: 26800, crecimiento: 6 }
                  ].map((mes, index) => (
                    <div key={index} className="flex flex-col items-center flex-1">
                      <div 
                        className="bg-blue-500 rounded-t-lg transition-all duration-500 hover:bg-blue-600 cursor-pointer relative group"
                        style={{ height: `${(mes.ventas / 30000) * 120}px`, width: '100%', minWidth: '20px' }}
                      >
                        <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-gray-800 text-white text-xs px-2 py-1 rounded opacity-0 group-hover:opacity-100 transition-opacity duration-200 whitespace-nowrap">
                          ${(mes.ventas/1000).toFixed(0)}K
                          <div className={`text-xs ${mes.crecimiento > 0 ? 'text-green-400' : 'text-red-400'}`}>
                            {mes.crecimiento > 0 ? '+' : ''}{mes.crecimiento}%
                          </div>
                        </div>
                      </div>
                      <div className="mt-2 text-center">
                        <div className="text-xs text-gray-600">{mes.mes}</div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grafico de Productos Mas Vendidos */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-800 mb-3">Top 5 Productos Mas Vendidos</h4>
                <div className="space-y-3">
                  {[
                    { producto: 'Ladrillo 6h', vendidos: 1200, color: 'bg-blue-500' },
                    { producto: 'Cemento 50kg', vendidos: 450, color: 'bg-green-500' },
                    { producto: 'Tornillos 3"', vendidos: 380, color: 'bg-yellow-500' },
                    { producto: 'Varilla 1/2"', vendidos: 280, color: 'bg-red-500' },
                    { producto: 'Pintura Blanca', vendidos: 190, color: 'bg-purple-500' }
                  ].map((item, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-700">{item.producto}</span>
                        <span className="font-medium text-gray-800">{item.vendidos} unid.</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${item.color} transition-all duration-500`}
                          style={{ width: `${(item.vendidos / 1200) * 100}%` }}
                        ></div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grafico de Eficiencia por Dia de la Semana */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-medium text-gray-800 mb-3">Ventas por Dia de la Semana</h4>
                <div className="space-y-3">
                  {[
                    { dia: 'Lunes', ventas: 820, promedio: 780, color: 'bg-blue-500' },
                    { dia: 'Martes', ventas: 750, promedio: 720, color: 'bg-green-500' },
                    { dia: 'Miercoles', ventas: 890, promedio: 850, color: 'bg-yellow-500' },
                    { dia: 'Jueves', ventas: 910, promedio: 880, color: 'bg-orange-500' },
                    { dia: 'Viernes', ventas: 980, promedio: 920, color: 'bg-red-500' },
                    { dia: 'Sabado', ventas: 650, promedio: 600, color: 'bg-purple-500' },
                    { dia: 'Domingo', ventas: 420, promedio: 380, color: 'bg-pink-500' }
                  ].map((item, index) => (
                    <div key={index} className="space-y-1">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-700">{item.dia}</span>
                        <span className="font-medium text-gray-800">${item.ventas}</span>
                      </div>
                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div 
                          className={`h-2 rounded-full ${item.color} transition-all duration-500`}
                          style={{ width: `${(item.ventas / 1000) * 100}%` }}
                        ></div>
                      </div>
                      <div className="text-xs text-gray-500">
                        Promedio: ${item.promedio} | {item.ventas > item.promedio ? '↑' : '↓'} ${Math.abs(item.ventas - item.promedio)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              {/* Grafico de Metas vs Real */}
              <div className="bg-gray-50 rounded-lg p-4 lg:col-span-2">
                <h4 className="font-medium text-gray-800 mb-3">Metas vs Real - Ultimos 6 Meses</h4>
                <div className="flex items-end justify-between h-32 px-4 border-b border-l border-gray-300 space-x-1">
                  {[
                    { mes: 'Jul', meta: 22000, real: 23500, color: 'bg-green-500' },
                    { mes: 'Ago', meta: 23000, real: 24200, color: 'bg-green-500' },
                    { mes: 'Sep', meta: 24000, real: 23800, color: 'bg-red-500' },
                    { mes: 'Oct', meta: 24000, real: 24500, color: 'bg-green-500' },
                    { mes: 'Nov', meta: 25000, real: 25200, color: 'bg-green-500' },
                    { mes: 'Dic', meta: 26000, real: 26800, color: 'bg-green-500' }
                  ].map((item, index) => (
                    <div key={index} className="flex flex-col items-center flex-1 space-y-1">
                      <div className="flex items-end space-x-1 w-full justify-center">
                        {/* Barra de Meta */}
                        <div 
                          className="bg-gray-400 rounded-t opacity-60"
                          style={{ height: `${(item.meta / 30000) * 100}px`, width: '40%' }}
                        ></div>
                        {/* Barra de Real */}
                        <div 
                          className={`${item.color} rounded-t transition-all duration-500`}
                          style={{ height: `${(item.real / 30000) * 100}px`, width: '40%' }}
                        ></div>
                      </div>
                      <div className="text-center">
                        <div className="text-xs text-gray-600">{item.mes}</div>
                        <div className={`text-xs font-medium ${item.real >= item.meta ? 'text-green-600' : 'text-red-600'}`}>
                          {item.real >= item.meta ? '+' : ''}{((item.real - item.meta) / item.meta * 100).toFixed(1)}%
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex justify-center space-x-4 mt-2">
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-gray-400 rounded"></div>
                    <span className="text-xs text-gray-600">Meta</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-green-500 rounded"></div>
                    <span className="text-xs text-gray-600">Real (Superado)</span>
                  </div>
                  <div className="flex items-center space-x-1">
                    <div className="w-3 h-3 bg-red-500 rounded"></div>
                    <span className="text-xs text-gray-600">Real (No Alcanzado)</span>
                  </div>
                </div>
              </div>

            </div>

            {/* Metricas de Rendimiento */}
            <div className="mt-6 grid grid-cols-2 md:grid-cols-4 gap-4">
              <div className="text-center p-3 bg-blue-50 rounded-lg border border-blue-200">
                <div className="text-xl font-bold text-blue-600">94%</div>
                <div className="text-xs text-blue-700">Eficiencia Operativa</div>
              </div>
              <div className="text-center p-3 bg-green-50 rounded-lg border border-green-200">
                <div className="text-xl font-bold text-green-600">2.8x</div>
                <div className="text-xs text-green-700">Rotacion Inventario</div>
              </div>
              <div className="text-center p-3 bg-purple-50 rounded-lg border border-purple-200">
                <div className="text-xl font-bold text-purple-600">33.5%</div>
                <div className="text-xs text-purple-700">Margen Ganancia</div>
              </div>
              <div className="text-center p-3 bg-orange-50 rounded-lg border border-orange-200">
                <div className="text-xl font-bold text-orange-600">15.8%</div>
                <div className="text-xs text-orange-700">Crecimiento Anual</div>
              </div>
            </div>

            <div className="mt-4 text-xs text-gray-500 text-center">
              Dashboard ejecutivo - Visualizacion completa de metricas del negocio
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default ReportesAvanzados;