import React, { useState } from 'react';

const AuditoriaCompleta = () => {
  const [filtroTipo, setFiltroTipo] = useState('todos');
  const [filtroUsuario, setFiltroUsuario] = useState('todos');

  const registrosAuditoria = [
    { id: 1, usuario: 'Carlos Ruiz', accion: 'Creo nuevo usuario', tipo: 'usuarios', fecha: '2024-01-15 14:30:25', detalles: 'Usuario: Maria Gonzalez' },
    { id: 2, usuario: 'Maria Gonzalez', accion: 'Proceso cierre diario', tipo: 'cierre', fecha: '2024-01-15 14:15:10', detalles: 'Ventas: $850, Productos: 15' },
    { id: 3, usuario: 'Juan Perez', accion: 'Ajuste de stock', tipo: 'inventario', fecha: '2024-01-15 13:45:30', detalles: 'Producto: Cemento 50kg, Cantidad: -2' },
    { id: 4, usuario: 'Sistema', accion: 'Backup automatico', tipo: 'sistema', fecha: '2024-01-15 02:00:00', detalles: 'Backup completado exitosamente' },
    { id: 5, usuario: 'Ana Torres', accion: 'Modifico configuracion', tipo: 'configuracion', fecha: '2024-01-14 16:20:15', detalles: 'Alerta stock bajo: 10 -> 8' },
    { id: 6, usuario: 'Carlos Ruiz', accion: 'Exporto reporte', tipo: 'reportes', fecha: '2024-01-14 11:10:05', detalles: 'Reporte de ventas mensual' }
  ];

  const usuarios = [...new Set(registrosAuditoria.map(r => r.usuario))];
  const tipos = [...new Set(registrosAuditoria.map(r => r.tipo))];

  const registrosFiltrados = registrosAuditoria.filter(registro => {
    const coincideTipo = filtroTipo === 'todos' || registro.tipo === filtroTipo;
    const coincideUsuario = filtroUsuario === 'todos' || registro.usuario === filtroUsuario;
    return coincideTipo && coincideUsuario;
  });

  const obtenerColorTipo = (tipo) => {
    switch(tipo) {
      case 'usuarios': return 'bg-blue-100 text-blue-800';
      case 'cierre': return 'bg-green-100 text-green-800';
      case 'inventario': return 'bg-yellow-100 text-yellow-800';
      case 'sistema': return 'bg-purple-100 text-purple-800';
      case 'configuracion': return 'bg-red-100 text-red-800';
      case 'reportes': return 'bg-indigo-100 text-indigo-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Auditoria del Sistema</h2>

      {/* Filtros */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Tipo</label>
          <select
            value={filtroTipo}
            onChange={(e) => setFiltroTipo(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="todos">Todos los tipos</option>
            {tipos.map(tipo => (
              <option key={tipo} value={tipo}>{tipo}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Filtrar por Usuario</label>
          <select
            value={filtroUsuario}
            onChange={(e) => setFiltroUsuario(e.target.value)}
            className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          >
            <option value="todos">Todos los usuarios</option>
            {usuarios.map(usuario => (
              <option key={usuario} value={usuario}>{usuario}</option>
            ))}
          </select>
        </div>
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">Acciones</label>
          <button className="w-full bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200">
            Exportar Auditoria
          </button>
        </div>
      </div>

      {/* Informacion de resultados */}
      <div className="mb-4 text-sm text-gray-600">
        Mostrando {registrosFiltrados.length} de {registrosAuditoria.length} registros
      </div>

      {/* Tabla de Auditoria */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Fecha y Hora</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Usuario</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tipo</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Accion</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Detalles</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {registrosFiltrados.map((registro) => (
              <tr key={registro.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm text-gray-900">{registro.fecha}</td>
                <td className="px-4 py-3 text-sm font-medium text-gray-900">{registro.usuario}</td>
                <td className="px-4 py-3 text-sm">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${obtenerColorTipo(registro.tipo)}`}>
                    {registro.tipo}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-800">{registro.accion}</td>
                <td className="px-4 py-3 text-sm text-gray-600">{registro.detalles}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {registrosFiltrados.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No se encontraron registros con los filtros aplicados
        </div>
      )}

      {/* Resumen de Auditoria */}
      <div className="mt-6 grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-blue-50 p-4 rounded-lg text-center">
          <p className="text-2xl font-bold text-blue-600">{registrosAuditoria.length}</p>
          <p className="text-sm text-blue-700">Total Registros</p>
        </div>
        <div className="bg-green-50 p-4 rounded-lg text-center">
          <p className="text-2xl font-bold text-green-600">{usuarios.length}</p>
          <p className="text-sm text-green-700">Usuarios Activos</p>
        </div>
        <div className="bg-yellow-50 p-4 rounded-lg text-center">
          <p className="text-2xl font-bold text-yellow-600">{tipos.length}</p>
          <p className="text-sm text-yellow-700">Tipos de Accion</p>
        </div>
        <div className="bg-purple-50 p-4 rounded-lg text-center">
          <p className="text-2xl font-bold text-purple-600">7</p>
          <p className="text-sm text-purple-700">Dias de Historial</p>
        </div>
      </div>
    </div>
  );
};

export default AuditoriaCompleta;