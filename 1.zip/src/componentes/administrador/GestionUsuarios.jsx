import React, { useState } from 'react';

const GestionUsuarios = () => {
  const [usuarios, setUsuarios] = useState([
    { id: 1, nombre: 'Juan Perez', email: 'juan@constrefri.com', rol: 'empleado', activo: true, ultimoAcceso: '2024-01-15' },
    { id: 2, nombre: 'Maria Gonzalez', email: 'maria@constrefri.com', rol: 'empleado', activo: true, ultimoAcceso: '2024-01-14' },
    { id: 3, nombre: 'Carlos Ruiz', email: 'carlos@constrefri.com', rol: 'administrador', activo: true, ultimoAcceso: '2024-01-15' },
    { id: 4, nombre: 'Ana Torres', email: 'ana@constrefri.com', rol: 'dueño', activo: true, ultimoAcceso: '2024-01-13' },
    { id: 5, nombre: 'Luis Mendoza', email: 'luis@constrefri.com', rol: 'empleado', activo: false, ultimoAcceso: '2023-12-20' }
  ]);

  const [mostrarFormulario, setMostrarFormulario] = useState(false);
  const [usuarioEditando, setUsuarioEditando] = useState(null);
  const [formData, setFormData] = useState({
    nombre: '',
    email: '',
    rol: 'empleado',
    activo: true
  });

  const manejarCrearUsuario = () => {
    const nuevoUsuario = {
      id: usuarios.length + 1,
      ...formData,
      ultimoAcceso: new Date().toISOString().split('T')[0]
    };
    setUsuarios([...usuarios, nuevoUsuario]);
    setMostrarFormulario(false);
    setFormData({ nombre: '', email: '', rol: 'empleado', activo: true });
  };

  const manejarEditarUsuario = (usuario) => {
    setUsuarioEditando(usuario);
    setFormData({
      nombre: usuario.nombre,
      email: usuario.email,
      rol: usuario.rol,
      activo: usuario.activo
    });
    setMostrarFormulario(true);
  };

  const manejarActualizarUsuario = () => {
    setUsuarios(usuarios.map(u => 
      u.id === usuarioEditando.id ? { ...u, ...formData } : u
    ));
    setMostrarFormulario(false);
    setUsuarioEditando(null);
    setFormData({ nombre: '', email: '', rol: 'empleado', activo: true });
  };

  const toggleEstadoUsuario = (id) => {
    setUsuarios(usuarios.map(u => 
      u.id === id ? { ...u, activo: !u.activo } : u
    ));
  };

  const obtenerColorRol = (rol) => {
    switch(rol) {
      case 'administrador': return 'bg-green-100 text-green-800';
      case 'dueño': return 'bg-purple-100 text-purple-800';
      default: return 'bg-blue-100 text-blue-800';
    }
  };

  const obtenerColorEstado = (activo) => {
    return activo ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800';
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <div className="flex justify-between items-center mb-6">
        <h2 className="text-2xl font-bold text-gray-800">Gestion de Usuarios</h2>
        <button
          onClick={() => setMostrarFormulario(true)}
          className="bg-blue-500 hover:bg-blue-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200"
        >
          Crear Usuario
        </button>
      </div>

      {/* Formulario de Usuario */}
      {mostrarFormulario && (
        <div className="bg-gray-50 p-6 rounded-lg mb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">
            {usuarioEditando ? 'Editar Usuario' : 'Crear Nuevo Usuario'}
          </h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Nombre</label>
              <input
                type="text"
                value={formData.nombre}
                onChange={(e) => setFormData({...formData, nombre: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Nombre completo"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                value={formData.email}
                onChange={(e) => setFormData({...formData, email: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="email@constrefri.com"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Rol</label>
              <select
                value={formData.rol}
                onChange={(e) => setFormData({...formData, rol: e.target.value})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="empleado">Empleado</option>
                <option value="administrador">Administrador</option>
                <option value="dueño">Dueño</option>
              </select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Estado</label>
              <select
                value={formData.activo}
                onChange={(e) => setFormData({...formData, activo: e.target.value === 'true'})}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value={true}>Activo</option>
                <option value={false}>Inactivo</option>
              </select>
            </div>
          </div>
          <div className="flex space-x-3 mt-4">
            <button
              onClick={usuarioEditando ? manejarActualizarUsuario : manejarCrearUsuario}
              className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200"
            >
              {usuarioEditando ? 'Actualizar' : 'Crear'} Usuario
            </button>
            <button
              onClick={() => {
                setMostrarFormulario(false);
                setUsuarioEditando(null);
                setFormData({ nombre: '', email: '', rol: 'empleado', activo: true });
              }}
              className="bg-gray-500 hover:bg-gray-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200"
            >
              Cancelar
            </button>
          </div>
        </div>
      )}

      {/* Tabla de Usuarios */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Usuario</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Email</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Rol</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ultimo Acceso</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Acciones</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {usuarios.map((usuario) => (
              <tr key={usuario.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-900">{usuario.nombre}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{usuario.email}</td>
                <td className="px-4 py-3 text-sm">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${obtenerColorRol(usuario.rol)}`}>
                    {usuario.rol}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${obtenerColorEstado(usuario.activo)}`}>
                    {usuario.activo ? 'Activo' : 'Inactivo'}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">{usuario.ultimoAcceso}</td>
                <td className="px-4 py-3 text-sm space-x-2">
                  <button
                    onClick={() => manejarEditarUsuario(usuario)}
                    className="text-blue-600 hover:text-blue-800 font-medium"
                  >
                    Editar
                  </button>
                  <button
                    onClick={() => toggleEstadoUsuario(usuario.id)}
                    className={`font-medium ${
                      usuario.activo ? 'text-red-600 hover:text-red-800' : 'text-green-600 hover:text-green-800'
                    }`}
                  >
                    {usuario.activo ? 'Desactivar' : 'Activar'}
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="mt-4 text-sm text-gray-600">
        Total: {usuarios.length} usuarios | Activos: {usuarios.filter(u => u.activo).length}
      </div>
    </div>
  );
};

export default GestionUsuarios;