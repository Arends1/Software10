import React, { useState } from 'react';
import GestionUsuarios from './GestionUsuarios';
import AuditoriaCompleta from './AuditoriaCompleta';
import ReportesAvanzados from './ReportesAvanzados';
import CierreDiario from '../empleado/CierreDiario';
import ConsultaInventario from '../empleado/ConsultaInventario';
import AjustesStock from '../empleado/AjustesStock';

const DashboardAdministrador = () => {
  const [seccionActiva, setSeccionActiva] = useState('inicio');

  // Datos para el dashboard
  const metricas = {
    ventasMes: 24500,
    usuariosActivos: 8,
    productosStockBajo: 12,
    cierresEsteMes: 22
  };

  const renderizarSeccion = () => {
    switch(seccionActiva) {
      case 'gestion-usuarios':
        return <GestionUsuarios />;
      case 'auditoria':
        return <AuditoriaCompleta />;
      case 'reportes-avanzados':
        return <ReportesAvanzados />;
      case 'cierre-diario':
        return <CierreDiario />;
      case 'consulta-inventario':
        return <ConsultaInventario />;
      case 'ajustes-stock':
        return <AjustesStock />;
      default:
        return (
          <div className="space-y-6">
            {/* Header del Dashboard */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h1 className="text-2xl font-bold text-gray-800">Dashboard Administrador</h1>
              <p className="text-gray-600">Panel de administracion completo de Constrefri</p>
            </div>

            {/* Metricas Rapidas */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-500">
                <h3 className="text-sm font-medium text-gray-500">Ventas del Mes</h3>
                <p className="text-2xl font-bold text-gray-800">${metricas.ventasMes}</p>
                <span className="text-xs text-green-500">+8% vs mes anterior</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-500">
                <h3 className="text-sm font-medium text-gray-500">Usuarios Activos</h3>
                <p className="text-2xl font-bold text-gray-800">{metricas.usuariosActivos}</p>
                <span className="text-xs text-gray-500">En sistema</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-yellow-500">
                <h3 className="text-sm font-medium text-gray-500">Stock Bajo</h3>
                <p className="text-2xl font-bold text-gray-800">{metricas.productosStockBajo}</p>
                <span className="text-xs text-red-500">Necesita atencion</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-purple-500">
                <h3 className="text-sm font-medium text-gray-500">Cierres del Mes</h3>
                <p className="text-2xl font-bold text-gray-800">{metricas.cierresEsteMes}</p>
                <span className="text-xs text-gray-500">Procesados</span>
              </div>
            </div>

            {/* Acciones de Administracion */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Gestion del Sistema</h3>
                <div className="space-y-3">
                  <button 
                    onClick={() => setSeccionActiva('gestion-usuarios')}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Gestionar Usuarios
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('auditoria')}
                    className="w-full bg-yellow-500 hover:bg-yellow-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Ver Auditoria
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('reportes-avanzados')}
                    className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Reportes Avanzados
                  </button>
                </div>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Operaciones</h3>
                <div className="space-y-3">
                  <button 
                    onClick={() => setSeccionActiva('cierre-diario')}
                    className="w-full bg-green-500 hover:bg-green-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Realizar Cierre Diario
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('consulta-inventario')}
                    className="w-full bg-indigo-500 hover:bg-indigo-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Consultar Inventario
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('ajustes-stock')}
                    className="w-full bg-red-500 hover:bg-red-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200"
                  >
                    Ajustes de Stock
                  </button>
                </div>
              </div>
            </div>

            {/* Alertas del Sistema */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Alertas del Sistema</h3>
              <div className="space-y-3">
                <div className="p-3 bg-red-50 rounded-lg border border-red-200">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">3 Productos Stock Critico</span>
                    <span className="text-red-600 font-bold">Urgente</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Cemento, Pegamento PVC, Brochas</p>
                </div>
                
                <div className="p-3 bg-yellow-50 rounded-lg border border-yellow-200">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">2 Usuarios Inactivos</span>
                    <span className="text-yellow-600 font-bold">Revisar</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Mas de 30 dias sin actividad</p>
                </div>
                
                <div className="p-3 bg-blue-50 rounded-lg border border-blue-200">
                  <div className="flex justify-between items-center">
                    <span className="font-medium text-gray-800">Backup Pendiente</span>
                    <span className="text-blue-600 font-bold">Programado</span>
                  </div>
                  <p className="text-sm text-gray-600 mt-1">Backup semanal esta noche</p>
                </div>
              </div>
            </div>

            {/* Actividad Reciente */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h3 className="text-lg font-semibold text-gray-800 mb-4">Actividad Reciente</h3>
              <div className="space-y-3">
                {[
                  { usuario: 'Maria Gonzalez', accion: 'Cierre diario procesado', fecha: 'Hoy 14:30' },
                  { usuario: 'Carlos Ruiz', accion: 'Ajuste de stock registrado', fecha: 'Hoy 13:15' },
                  { usuario: 'Ana Torres', accion: 'Nuevo usuario creado', fecha: 'Ayer 16:45' },
                  { usuario: 'Sistema', accion: 'Backup automatico completado', fecha: 'Ayer 02:00' }
                ].map((actividad, index) => (
                  <div key={index} className="flex justify-between items-center p-3 bg-gray-50 rounded-lg">
                    <div>
                      <p className="font-medium text-gray-800">{actividad.usuario}</p>
                      <p className="text-sm text-gray-600">{actividad.accion}</p>
                    </div>
                    <span className="text-sm text-gray-500">{actividad.fecha}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {seccionActiva !== 'inicio' && (
        <button 
          onClick={() => setSeccionActiva('inicio')}
          className="mb-4 flex items-center text-blue-600 hover:text-blue-800 transition duration-200"
        >
          ← Volver al Dashboard
        </button>
      )}
      {renderizarSeccion()}
    </div>
  );
};

export default DashboardAdministrador;