import React, { useState } from 'react';

const ConfiguracionSistema = () => {
  const [configuraciones, setConfiguraciones] = useState({
    empresa: {
      nombre: 'Constrefri',
      telefono: '+1234567890',
      direccion: 'Av. Principal 123',
      email: 'info@constrefri.com'
    },
    inventario: {
      alertaStockBajo: 10,
      alertaStockCritico: 5,
      diasBackup: 7
    },
    sistema: {
      horarioApertura: '08:00',
      horarioCierre: '18:00',
      tiempoSesion: 60
    }
  });

  const [guardando, setGuardando] = useState(false);

  const manejarGuardar = async () => {
    setGuardando(true);
    await new Promise(resolve => setTimeout(resolve, 1500));
    setGuardando(false);
    alert('Configuraciones guardadas exitosamente');
  };

  const actualizarConfiguracion = (seccion, campo, valor) => {
    setConfiguraciones(prev => ({
      ...prev,
      [seccion]: {
        ...prev[seccion],
        [campo]: valor
      }
    }));
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Configuracion del Sistema</h2>

      <div className="space-y-8">
        {/* Configuracion de Empresa */}
        <div className="border-b pb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Informacion de la Empresa</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Nombre de la Empresa</label>
              <input
                type="text"
                value={configuraciones.empresa.nombre}
                onChange={(e) => actualizarConfiguracion('empresa', 'nombre', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Telefono</label>
              <input
                type="text"
                value={configuraciones.empresa.telefono}
                onChange={(e) => actualizarConfiguracion('empresa', 'telefono', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Direccion</label>
              <input
                type="text"
                value={configuraciones.empresa.direccion}
                onChange={(e) => actualizarConfiguracion('empresa', 'direccion', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div className="md:col-span-2">
              <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
              <input
                type="email"
                value={configuraciones.empresa.email}
                onChange={(e) => actualizarConfiguracion('empresa', 'email', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
          </div>
        </div>

        {/* Configuracion de Inventario */}
        <div className="border-b pb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Configuracion de Inventario</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Alerta Stock Bajo</label>
              <input
                type="number"
                value={configuraciones.inventario.alertaStockBajo}
                onChange={(e) => actualizarConfiguracion('inventario', 'alertaStockBajo', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">Unidades minimas para alerta amarilla</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Alerta Stock Critico</label>
              <input
                type="number"
                value={configuraciones.inventario.alertaStockCritico}
                onChange={(e) => actualizarConfiguracion('inventario', 'alertaStockCritico', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">Unidades minimas para alerta roja</p>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Dias entre Backups</label>
              <input
                type="number"
                value={configuraciones.inventario.diasBackup}
                onChange={(e) => actualizarConfiguracion('inventario', 'diasBackup', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">Frecuencia de respaldos automaticos</p>
            </div>
          </div>
        </div>

        {/* Configuracion del Sistema */}
        <div className="border-b pb-6">
          <h3 className="text-lg font-semibold text-gray-800 mb-4">Configuracion del Sistema</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Horario de Apertura</label>
              <input
                type="time"
                value={configuraciones.sistema.horarioApertura}
                onChange={(e) => actualizarConfiguracion('sistema', 'horarioApertura', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Horario de Cierre</label>
              <input
                type="time"
                value={configuraciones.sistema.horarioCierre}
                onChange={(e) => actualizarConfiguracion('sistema', 'horarioCierre', e.target.value)}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">Tiempo de Sesion (min)</label>
              <input
                type="number"
                value={configuraciones.sistema.tiempoSesion}
                onChange={(e) => actualizarConfiguracion('sistema', 'tiempoSesion', parseInt(e.target.value))}
                className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
              <p className="text-xs text-gray-500 mt-1">Minutos de inactividad antes de cerrar sesion</p>
            </div>
          </div>
        </div>

        {/* Botones de Accion */}
        <div className="flex space-x-4">
          <button
            onClick={manejarGuardar}
            disabled={guardando}
            className="bg-blue-500 hover:bg-blue-600 disabled:bg-gray-400 text-white px-6 py-3 rounded-lg font-medium transition duration-200 disabled:cursor-not-allowed"
          >
            {guardando ? 'Guardando...' : 'Guardar Configuraciones'}
          </button>
          <button
            onClick={() => window.location.reload()}
            className="bg-gray-500 hover:bg-gray-600 text-white px-6 py-3 rounded-lg font-medium transition duration-200"
          >
            Restablecer Valores
          </button>
        </div>
      </div>
    </div>
  );
};

export default ConfiguracionSistema;