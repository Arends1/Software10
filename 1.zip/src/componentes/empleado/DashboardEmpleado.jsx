import React, { useState } from 'react';
import CierreDiario from './CierreDiario';
import ConsultaInventario from './ConsultaInventario';
import AjustesStock from './AjustesStock';
import ReportesBasicos from './ReportesBasicos';

const DashboardEmpleado = () => {
  const [seccionActiva, setSeccionActiva] = useState('inicio');

  // Datos reales para empresa pequeña
  const metricas = {
    ventasHoy: 850,
    productosVendidos: 15,
    stockBajo: 3,
    cierrePendiente: true
  };

  const renderizarSeccion = () => {
    switch(seccionActiva) {
      case 'cierre-diario':
        return <CierreDiario />;
      case 'consulta-inventario':
        return <ConsultaInventario />;
      case 'ajustes-stock':
        return <AjustesStock />;
      case 'reportes':
        return <ReportesBasicos />;
      default:
        return (
          <div className="space-y-6">
            {/* Header del Dashboard */}
            <div className="bg-white rounded-xl shadow-sm p-6">
              <h1 className="text-2xl font-bold text-gray-800">Dashboard Empleado</h1>
              <p className="text-gray-600">Bienvenido al sistema de gestión de Constrefri</p>
            </div>

            {/* Métricas Rápidas */}
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-blue-500">
                <h3 className="text-sm font-medium text-gray-500">Ventas Hoy</h3>
                <p className="text-2xl font-bold text-gray-800">${metricas.ventasHoy}</p>
                <span className="text-xs text-green-500">+5% vs ayer</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-green-500">
                <h3 className="text-sm font-medium text-gray-500">Productos Vendidos</h3>
                <p className="text-2xl font-bold text-gray-800">{metricas.productosVendidos}</p>
                <span className="text-xs text-gray-500">Hoy</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-yellow-500">
                <h3 className="text-sm font-medium text-gray-500">Stock Bajo</h3>
                <p className="text-2xl font-bold text-gray-800">{metricas.stockBajo}</p>
                <span className="text-xs text-red-500">Necesita atención</span>
              </div>

              <div className="bg-white rounded-xl shadow-sm p-6 border-l-4 border-purple-500">
                <h3 className="text-sm font-medium text-gray-500">Cierre Diario</h3>
                <p className="text-2xl font-bold text-gray-800">{metricas.cierrePendiente ? 'Pendiente' : 'Completado'}</p>
                <span className="text-xs text-orange-500">Por procesar</span>
              </div>
            </div>

            {/* Acciones Rápidas */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Acciones Rápidas</h3>
                <div className="space-y-3">
                  <button 
                    onClick={() => setSeccionActiva('cierre-diario')}
                    className="w-full bg-blue-500 hover:bg-blue-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200 flex items-center justify-center"
                  >
                    Realizar Cierre Diario
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('consulta-inventario')}
                    className="w-full bg-green-500 hover:bg-green-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200 flex items-center justify-center"
                  >
                    Consultar Inventario
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('ajustes-stock')}
                    className="w-full bg-yellow-500 hover:bg-yellow-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200 flex items-center justify-center"
                  >
                    Ajustar Stock (Mermas)
                  </button>
                  <button 
                    onClick={() => setSeccionActiva('reportes')}
                    className="w-full bg-purple-500 hover:bg-purple-600 text-white py-3 px-4 rounded-lg font-medium transition duration-200 flex items-center justify-center"
                  >
                    Ver Reportes Básicos
                  </button>
                </div>
              </div>

              {/* Productos con Stock Bajo */}
              <div className="bg-white rounded-xl shadow-sm p-6">
                <h3 className="text-lg font-semibold text-gray-800 mb-4">Productos con Stock Bajo</h3>
                <div className="space-y-3">
                  {[
                    { nombre: 'Cemento 50kg', stock: 3, minimo: 10 },
                    { nombre: 'Tornillos 3"', stock: 8, minimo: 20 },
                    { nombre: 'Pegamento PVC', stock: 2, minimo: 5 }
                  ].map((producto, index) => (
                    <div key={index} className="flex justify-between items-center p-3 bg-red-50 rounded-lg border border-red-200">
                      <span className="font-medium text-gray-800">{producto.nombre}</span>
                      <span className="text-red-600 font-bold">{producto.stock} unidades</span>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </div>
        );
    }
  };

  return (
    <div className="max-w-7xl mx-auto">
      {seccionActiva !== 'inicio' && (
        <button 
          onClick={() => setSeccionActiva('inicio')}
          className="mb-4 flex items-center text-blue-600 hover:text-blue-800 transition duration-200"
        >
          ← Volver al Dashboard
        </button>
      )}
      {renderizarSeccion()}
    </div>
  );
};

export default DashboardEmpleado;