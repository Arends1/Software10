import React, { useState } from 'react';

const CierreDiario = () => {
  const [archivo, setArchivo] = useState(null);
  const [procesando, setProcesando] = useState(false);
  const [resultado, setResultado] = useState(null);
  const [pasoActual, setPasoActual] = useState(1);
  const [modoDemo, setModoDemo] = useState(false);

  // Datos de ejemplo para la demo
  const datosDemo = {
    nombreArchivo: 'ventas_valery_15012024.csv',
    tamaño: '4.2 KB',
    detalles: [
      { producto: 'Cemento 50kg', vendido: 2, stockAnterior: 25, stockNuevo: 23, precio: 120, total: 240 },
      { producto: 'Varilla 1/2"', vendido: 3, stockAnterior: 50, stockNuevo: 47, precio: 40, total: 120 },
      { producto: 'Tornillos 3"', vendido: 5, stockAnterior: 100, stockNuevo: 95, precio: 8, total: 40 },
      { producto: 'Pegamento PVC', vendido: 1, stockAnterior: 12, stockNuevo: 11, precio: 25, total: 25 },
      { producto: 'Ladrillo 6h', vendido: 15, stockAnterior: 200, stockNuevo: 185, precio: 2, total: 30 },
      { producto: 'Arena Fina', vendido: 8, stockAnterior: 80, stockNuevo: 72, precio: 15, total: 120 }
    ],
    totalVentas: 575,
    productosProcesados: 6,
    transacciones: 8
  };

  const manejarSubidaArchivo = (e) => {
    const file = e.target.files[0];
    if (file && file.name.endsWith('.csv')) {
      setArchivo(file);
      setPasoActual(2);
      setModoDemo(false);
    } else {
      alert('Por favor selecciona un archivo CSV valido de Valery');
    }
  };

  const iniciarDemo = () => {
    setModoDemo(true);
    setPasoActual(2);
  };

  const procesarCierre = async () => {
    setProcesando(true);
    setPasoActual(3);
    
    // Simular procesamiento
    setTimeout(() => {
      setResultado({
        exitoso: true,
        totalVentas: modoDemo ? datosDemo.totalVentas : 850,
        productosProcesados: modoDemo ? datosDemo.productosProcesados : 15,
        transacciones: modoDemo ? datosDemo.transacciones : 8,
        detalles: modoDemo ? datosDemo.detalles : [
          { producto: 'Cemento 50kg', vendido: 2, stockAnterior: 25, stockNuevo: 23 },
          { producto: 'Varilla 1/2"', vendido: 3, stockAnterior: 50, stockNuevo: 47 },
          { producto: 'Tornillos 3"', vendido: 5, stockAnterior: 100, stockNuevo: 95 },
          { producto: 'Pegamento PVC', vendido: 1, stockAnterior: 12, stockNuevo: 11 }
        ]
      });
      setProcesando(false);
      setPasoActual(4);
    }, 3000);
  };

  const reiniciarProceso = () => {
    setResultado(null);
    setArchivo(null);
    setPasoActual(1);
    setModoDemo(false);
  };

  // Pasos del proceso
  const pasos = [
    { numero: 1, titulo: 'Cargar Archivo', descripcion: 'Selecciona el archivo CSV exportado de Valery' },
    { numero: 2, titulo: 'Vista Previa', descripcion: 'Revisa los datos antes de procesar' },
    { numero: 3, titulo: 'Procesamiento', descripcion: 'El sistema actualiza inventario y ventas' },
    { numero: 4, titulo: 'Resultados Actualizados', descripcion: 'Verifica los cambios realizados' }
  ];

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Cierre Diario</h2>
      
      {/* Stepper de Progreso */}
      <div className="mb-8">
        <div className="flex justify-between items-center">
          {pasos.map((paso, index) => (
            <div key={paso.numero} className="flex flex-col items-center flex-1">
              {/* Linea conectadora */}
              {index > 0 && (
                <div className={`w-full h-1 absolute top-4 -z-10 ${
                  pasoActual >= paso.numero ? 'bg-blue-500' : 'bg-gray-300'
                }`} style={{ marginLeft: '-50%' }}></div>
              )}
              
              {/* Circulo del paso */}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-semibold mb-2 ${
                pasoActual >= paso.numero 
                  ? 'bg-blue-500 text-white' 
                  : 'bg-gray-300 text-gray-600'
              }`}>
                {paso.numero}
              </div>
              
              {/* Texto del paso */}
              <div className="text-center">
                <p className={`text-sm font-medium ${
                  pasoActual >= paso.numero ? 'text-blue-600' : 'text-gray-500'
                }`}>
                  {paso.titulo}
                </p>
                <p className="text-xs text-gray-500 mt-1 hidden md:block">
                  {paso.descripcion}
                </p>
              </div>
            </div>
          ))}
        </div>
      </div>

      {modoDemo && (
        <div className="bg-purple-50 border border-purple-200 rounded-lg p-4 mb-6">
          <div className="flex items-center">
            <span className="bg-purple-500 text-white px-2 py-1 rounded text-sm font-medium mr-3">
              MODO DEMO
            </span>
            <p className="text-purple-700">
              Vista previa del proceso - Usando datos de ejemplo
            </p>
          </div>
        </div>
      )}

      {!resultado ? (
        <div className="space-y-6">
          {/* Paso 1: Cargar Archivo */}
          {pasoActual === 1 && (
            <div className="space-y-6">
              <div className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center">
                <div className="mb-4">
                  <h3 className="text-lg font-semibold text-gray-800 mb-2">Paso 1: Cargar Archivo CSV</h3>
                  <p className="text-gray-600">Selecciona el archivo de ventas exportado desde Valery</p>
                </div>
                
                <input
                  type="file"
                  accept=".csv"
                  onChange={manejarSubidaArchivo}
                  className="hidden"
                  id="archivo-csv"
                />
                <label
                  htmlFor="archivo-csv"
                  className="cursor-pointer bg-blue-500 text-white px-6 py-3 rounded-lg hover:bg-blue-600 transition duration-200 inline-block mb-4"
                >
                  Seleccionar Archivo CSV
                </label>
                
                <div className="mt-4 text-sm text-gray-500">
                  <p>Formato esperado: CSV exportado directamente de Valery</p>
                  <p>El archivo debe contener columnas: Producto, Cantidad, Precio</p>
                </div>
              </div>

              {/* Botón de Demo */}
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-6 text-center">
                <h3 className="text-lg font-semibold text-yellow-800 mb-2">¿Quieres ver una vista previa?</h3>
                <p className="text-yellow-700 mb-4">Puedes explorar todo el proceso con datos de ejemplo</p>
                <button
                  onClick={iniciarDemo}
                  className="bg-yellow-500 hover:bg-yellow-600 text-white px-6 py-3 rounded-lg font-medium transition duration-200"
                >
                  Ver Vista Previa del Proceso
                </button>
              </div>
            </div>
          )}

          {/* Paso 2: Vista Previa */}
          {pasoActual === 2 && (
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-blue-800 mb-2">Paso 2: Vista Previa</h3>
                <p className="text-blue-700">
                  {modoDemo 
                    ? "Vista previa con datos de ejemplo. Revisa la informacion antes de procesar." 
                    : "Archivo seleccionado correctamente. Revisa la informacion antes de procesar."
                  }
                </p>
                
                <div className="mt-4 p-4 bg-white rounded-lg">
                  <p className="font-medium text-gray-800">
                    Archivo: <span className="text-green-600">
                      {modoDemo ? datosDemo.nombreArchivo : archivo?.name}
                    </span>
                  </p>
                  <p className="text-sm text-gray-600 mt-1">
                    Tamaño: {modoDemo ? datosDemo.tamaño : ((archivo?.size || 0) / 1024).toFixed(2)} KB
                  </p>
                  <p className="text-sm text-gray-600">Tipo: {archivo?.type || 'CSV'}</p>
                </div>
              </div>

              {/* Vista Previa de Datos */}
              <div className="bg-gray-50 rounded-lg p-6">
                <h4 className="font-semibold text-gray-800 mb-3">Vista Previa de Datos {modoDemo && '(Ejemplo)'}</h4>
                <div className="overflow-x-auto">
                  <table className="min-w-full divide-y divide-gray-200">
                    <thead className="bg-gray-100">
                      <tr>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Producto</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Cantidad</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Precio Unitario</th>
                        <th className="px-4 py-2 text-left text-xs font-medium text-gray-500 uppercase">Total</th>
                      </tr>
                    </thead>
                    <tbody className="bg-white divide-y divide-gray-200">
                      {(modoDemo ? datosDemo.detalles : [
                        { producto: 'Cemento 50kg', vendido: 2, precio: 120, total: 240 },
                        { producto: 'Varilla 1/2"', vendido: 3, precio: 40, total: 120 },
                        { producto: 'Tornillos 3"', vendido: 5, precio: 8, total: 40 }
                      ]).slice(0, 6).map((item, index) => (
                        <tr key={index}>
                          <td className="px-4 py-2 text-sm text-gray-900">{item.producto}</td>
                          <td className="px-4 py-2 text-sm text-gray-500">{item.vendido}</td>
                          <td className="px-4 py-2 text-sm text-gray-500">${item.precio}</td>
                          <td className="px-4 py-2 text-sm font-semibold text-gray-900">${item.total}</td>
                        </tr>
                      ))}
                    </tbody>
                    <tfoot className="bg-gray-50">
                      <tr>
                        <td colSpan="3" className="px-4 py-2 text-sm font-semibold text-gray-800 text-right">Total:</td>
                        <td className="px-4 py-2 text-sm font-bold text-green-600">
                          ${modoDemo ? datosDemo.totalVentas : '850'}
                        </td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                {modoDemo && (
                  <p className="text-xs text-gray-500 mt-2 text-center">
                    Estos son datos de ejemplo para mostrar el funcionamiento del sistema.
                  </p>
                )}
              </div>
            </div>
          )}

          {/* Paso 3: Procesamiento */}
          {pasoActual === 3 && (
            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-8 text-center">
              <h3 className="text-lg font-semibold text-yellow-800 mb-4">Paso 3: Procesamiento</h3>
              
              <div className="flex items-center justify-center mb-4">
                <div className="w-12 h-12 border-t-2 border-yellow-600 border-solid rounded-full animate-spin mr-4"></div>
                <div>
                  <p className="text-yellow-700 font-medium">Procesando cierre diario...</p>
                  <p className="text-sm text-yellow-600">Actualizando inventario y registrando ventas</p>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mt-6">
                <div className="bg-white rounded-lg p-3">
                  <p className="text-sm text-gray-600">Leyendo {modoDemo ? 'datos' : 'archivo CSV'}</p>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div className="bg-green-500 h-2 rounded-full" style={{ width: '100%' }}></div>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <p className="text-sm text-gray-600">Actualizando inventario</p>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div className="bg-blue-500 h-2 rounded-full" style={{ width: '75%' }}></div>
                  </div>
                </div>
                <div className="bg-white rounded-lg p-3">
                  <p className="text-sm text-gray-600">Registrando ventas</p>
                  <div className="w-full bg-gray-200 rounded-full h-2 mt-2">
                    <div className="bg-purple-500 h-2 rounded-full" style={{ width: '50%' }}></div>
                  </div>
                </div>
              </div>
            </div>
          )}

          {/* Botón de Procesar (solo visible en paso 2) */}
          {pasoActual === 2 && (
            <button
              onClick={procesarCierre}
              disabled={procesando}
              className="w-full bg-green-500 hover:bg-green-600 disabled:bg-gray-400 text-white py-4 px-6 rounded-lg font-semibold text-lg transition duration-200 disabled:cursor-not-allowed"
            >
              {modoDemo ? 'Procesar Vista Previa' : 'Confirmar y Procesar Cierre'}
            </button>
          )}
        </div>
      ) : (
        /* Paso 4: Resultados */
        <div className="space-y-6">
          <div className="bg-green-50 border border-green-200 rounded-xl p-6">
            <h3 className="text-xl font-bold text-green-800 mb-2">Paso 4: Resultados Actualizados</h3>
            <p className="text-green-700 mb-4">
              {modoDemo 
                ? 'Vista previa completada - Proceso simulado exitosamente' 
                : 'El cierre diario ha sido procesado exitosamente'
              }
            </p>
            
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-6">
              <div className="bg-white rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-blue-600">${resultado.totalVentas}</p>
                <p className="text-sm text-gray-600">Total Ventas</p>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-green-600">{resultado.productosProcesados}</p>
                <p className="text-sm text-gray-600">Productos Procesados</p>
              </div>
              <div className="bg-white rounded-lg p-4 text-center">
                <p className="text-2xl font-bold text-purple-600">{resultado.transacciones}</p>
                <p className="text-sm text-gray-600">Transacciones</p>
              </div>
            </div>

            <h4 className="font-semibold text-gray-800 mb-3">Detalles del Inventario Actualizado:</h4>
            <div className="overflow-x-auto">
              <table className="min-w-full divide-y divide-gray-200">
                <thead className="bg-gray-50">
                  <tr>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Producto</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Vendido</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock Anterior</th>
                    <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock Nuevo</th>
                  </tr>
                </thead>
                <tbody className="bg-white divide-y divide-gray-200">
                  {resultado.detalles.map((item, index) => (
                    <tr key={index}>
                      <td className="px-4 py-3 text-sm font-medium text-gray-900">{item.producto}</td>
                      <td className="px-4 py-3 text-sm text-gray-500">{item.vendido}</td>
                      <td className="px-4 py-3 text-sm text-gray-500">{item.stockAnterior}</td>
                      <td className="px-4 py-3 text-sm font-semibold text-gray-900">{item.stockNuevo}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          <div className="flex space-x-4">
            <button
              onClick={reiniciarProceso}
              className="bg-blue-500 hover:bg-blue-600 text-white py-3 px-6 rounded-lg font-medium transition duration-200"
            >
              {modoDemo ? 'Ver Otra Vista Previa' : 'Realizar Otro Cierre'}
            </button>
            {modoDemo && (
              <button
                onClick={() => {
                  setModoDemo(false);
                  reiniciarProceso();
                }}
                className="bg-gray-500 hover:bg-gray-600 text-white py-3 px-6 rounded-lg font-medium transition duration-200"
              >
                Usar Archivo Real
              </button>
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default CierreDiario;