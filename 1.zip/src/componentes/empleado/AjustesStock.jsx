import React, { useState } from 'react';

const AjustesStock = () => {
  const [productoSeleccionado, setProductoSeleccionado] = useState('');
  const [cantidad, setCantidad] = useState('');
  const [motivo, setMotivo] = useState('');
  const [observaciones, setObservaciones] = useState('');
  const [enviando, setEnviando] = useState(false);

  // Productos de ejemplo
  const productos = [
    { id: 1, nombre: 'Cemento 50kg', stock: 3 },
    { id: 2, nombre: 'Varilla 1/2"', stock: 5 },
    { id: 3, nombre: 'Tornillos 3"', stock: 8 },
    { id: 4, nombre: 'Pegamento PVC', stock: 2 },
    { id: 5, nombre: 'Ladrillo 6h', stock: 150 }
  ];

  const productoActual = productos.find(p => p.id === parseInt(productoSeleccionado));

  const manejarEnvio = async (e) => {
    e.preventDefault();
    setEnviando(true);

    // Simular envio
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    alert(`Merma registrada: ${cantidad} unidades de ${productoActual?.nombre}`);
    
    // Resetear formulario
    setProductoSeleccionado('');
    setCantidad('');
    setMotivo('');
    setObservaciones('');
    setEnviando(false);
  };

  const stockDespues = productoActual ? productoActual.stock - parseInt(cantidad || 0) : 0;

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-sm p-6">
        <h2 className="text-2xl font-bold text-gray-800 mb-2">Ajustes de Stock - Mermas</h2>
        <p className="text-gray-600 mb-6">Registra perdidas, daños o mermas de inventario</p>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Formulario */}
          <div>
            <form onSubmit={manejarEnvio} className="space-y-4">
              {/* Producto */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Producto *
                </label>
                <select
                  value={productoSeleccionado}
                  onChange={(e) => setProductoSeleccionado(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Seleccionar producto</option>
                  {productos.map(producto => (
                    <option key={producto.id} value={producto.id}>
                      {producto.nombre} (Stock: {producto.stock})
                    </option>
                  ))}
                </select>
              </div>

              {/* Stock Actual (solo lectura) */}
              {productoActual && (
                <div className="bg-blue-50 p-3 rounded-lg">
                  <p className="text-sm text-blue-700">
                    <strong>Stock actual:</strong> {productoActual.stock} unidades
                  </p>
                </div>
              )}

              {/* Cantidad a descontar */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Cantidad a Descontar *
                </label>
                <input
                  type="number"
                  min="1"
                  max={productoActual ? productoActual.stock : 1}
                  value={cantidad}
                  onChange={(e) => setCantidad(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Ej: 2"
                  required
                />
                <p className="text-xs text-gray-500 mt-1">
                  Maximo: {productoActual ? productoActual.stock : 0} unidades disponibles
                </p>
              </div>

              {/* Stock después del ajuste */}
              {productoActual && cantidad && (
                <div className={`p-3 rounded-lg ${stockDespues < 0 ? 'bg-red-50' : 'bg-green-50'}`}>
                  <p className={`text-sm ${stockDespues < 0 ? 'text-red-700' : 'text-green-700'}`}>
                    <strong>Stock después del ajuste:</strong> {stockDespues} unidades
                    {stockDespues < 0 && ' No hay suficiente stock'}
                  </p>
                </div>
              )}

              {/* Motivo */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Motivo de la Merma *
                </label>
                <select
                  value={motivo}
                  onChange={(e) => setMotivo(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  required
                >
                  <option value="">Seleccionar motivo</option>
                  <option value="merma">Merma Normal</option>
                  <option value="daño">Producto Dañado</option>
                  <option value="perdida">Perdida</option>
                  <option value="calidad">No Cumple Calidad</option>
                  <option value="otros">Otros</option>
                </select>
              </div>

              {/* Observaciones */}
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Observaciones
                </label>
                <textarea
                  value={observaciones}
                  onChange={(e) => setObservaciones(e.target.value)}
                  rows="3"
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  placeholder="Detalles adicionales sobre la merma..."
                />
              </div>

              {/* Botón Enviar */}
              <button
                type="submit"
                disabled={enviando || stockDespues < 0 || !productoSeleccionado || !cantidad || !motivo}
                className="w-full bg-red-500 hover:bg-red-600 disabled:bg-gray-400 text-white py-3 px-4 rounded-lg font-semibold transition duration-200 disabled:cursor-not-allowed"
              >
                {enviando ? (
                  <div className="flex items-center justify-center">
                    <div className="w-5 h-5 border-t-2 border-white border-solid rounded-full animate-spin mr-2"></div>
                    Registrando Merma...
                  </div>
                ) : (
                  'Registrar Merma'
                )}
              </button>
            </form>
          </div>

          {/* Información y Historial */}
          <div>
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
              <h3 className="font-semibold text-yellow-800 mb-2">Restricciones del Empleado</h3>
              <ul className="text-sm text-yellow-700 space-y-1">
                <li>• Solo puedes registrar mermas (descuentos)</li>
                <li>• No puedes aumentar el stock</li>
                <li>• Cada merma queda registrada en el sistema</li>
                <li>• El administrador revisara los ajustes</li>
              </ul>
            </div>

            {/* Historial reciente */}
            <div className="bg-gray-50 rounded-lg p-4">
              <h3 className="font-semibold text-gray-800 mb-3">Historial Reciente</h3>
              <div className="space-y-2">
                {[
                  { producto: 'Tornillos 3"', cantidad: 2, motivo: 'Merma Normal', fecha: 'Hoy' },
                  { producto: 'Pegamento PVC', cantidad: 1, motivo: 'Daño', fecha: 'Ayer' },
                  { producto: 'Varilla 1/2"', cantidad: 3, motivo: 'Perdida', fecha: '05/11' }
                ].map((item, index) => (
                  <div key={index} className="bg-white p-3 rounded border">
                    <div className="flex justify-between">
                      <span className="font-medium text-gray-800">{item.producto}</span>
                      <span className="text-red-600 font-bold">-{item.cantidad}</span>
                    </div>
                    <div className="text-xs text-gray-500">
                      {item.motivo} • {item.fecha}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AjustesStock;