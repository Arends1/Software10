import React, { useState } from 'react';

const ConsultaInventario = () => {
  const [busqueda, setBusqueda] = useState('');
  const [categoria, setCategoria] = useState('todos');
  const [estadoStock, setEstadoStock] = useState('todos');

  // Datos de ejemplo del inventario
  const inventario = [
    { id: 1, producto: 'Cemento 50kg', categoria: 'Materiales', stock: 3, minimo: 10, ubicacion: 'Bodega A', estado: 'critico' },
    { id: 2, producto: 'Varilla 1/2"', categoria: 'Materiales', stock: 5, minimo: 15, ubicacion: 'Bodega B', estado: 'bajo' },
    { id: 3, producto: 'Tornillos 3"', categoria: 'Fijaciones', stock: 8, minimo: 20, ubicacion: 'Estante 3', estado: 'bajo' },
    { id: 4, producto: 'Pegamento PVC', categoria: 'Adhesivos', stock: 2, minimo: 5, ubicacion: 'Estante 1', estado: 'critico' },
    { id: 5, producto: 'Ladrillo 6h', categoria: 'Materiales', stock: 150, minimo: 50, ubicacion: 'Patio', estado: 'normal' },
    { id: 6, producto: 'Arena Fina', categoria: 'Materiales', stock: 45, minimo: 20, ubicacion: 'Patio', estado: 'normal' },
    { id: 7, producto: 'Pintura Blanca', categoria: 'Acabados', stock: 12, minimo: 8, ubicacion: 'Estante 2', estado: 'normal' },
    { id: 8, producto: 'Brocha 4"', categoria: 'Herramientas', stock: 6, minimo: 10, ubicacion: 'Estante 4', estado: 'bajo' }
  ];

  const filtrarInventario = inventario.filter(item => {
    const coincideBusqueda = item.producto.toLowerCase().includes(busqueda.toLowerCase());
    const coincideCategoria = categoria === 'todos' || item.categoria === categoria;
    const coincideEstado = estadoStock === 'todos' || item.estado === estadoStock;
    
    return coincideBusqueda && coincideCategoria && coincideEstado;
  });

  const obtenerColorEstado = (estado) => {
    switch(estado) {
      case 'normal': return 'bg-green-100 text-green-800';
      case 'bajo': return 'bg-yellow-100 text-yellow-800';
      case 'critico': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const obtenerTextoEstado = (estado) => {
    switch(estado) {
      case 'normal': return 'Normal';
      case 'bajo': return 'Stock Bajo';
      case 'critico': return 'Stock Critico';
      default: return 'Desconocido';
    }
  };

  return (
    <div className="bg-white rounded-xl shadow-sm p-6">
      <h2 className="text-2xl font-bold text-gray-800 mb-6">Consulta de Inventario</h2>
      
      {/* Filtros y Busqueda */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-6">
        <div className="md:col-span-2">
          <input
            type="text"
            placeholder="Buscar producto..."
            value={busqueda}
            onChange={(e) => setBusqueda(e.target.value)}
            className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        
        <select
          value={categoria}
          onChange={(e) => setCategoria(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="todos">Todas las categorias</option>
          <option value="Materiales">Materiales</option>
          <option value="Fijaciones">Fijaciones</option>
          <option value="Adhesivos">Adhesivos</option>
          <option value="Acabados">Acabados</option>
          <option value="Herramientas">Herramientas</option>
        </select>
        
        <select
          value={estadoStock}
          onChange={(e) => setEstadoStock(e.target.value)}
          className="px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
        >
          <option value="todos">Todos los estados</option>
          <option value="normal">Stock Normal</option>
          <option value="bajo">Stock Bajo</option>
          <option value="critico">Stock Critico</option>
        </select>
      </div>

      {/* Información de resultados */}
      <div className="mb-4 text-sm text-gray-600">
        Mostrando {filtrarInventario.length} de {inventario.length} productos
      </div>

      {/* Tabla de Inventario */}
      <div className="overflow-x-auto">
        <table className="min-w-full divide-y divide-gray-200">
          <thead className="bg-gray-50">
            <tr>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Producto</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Categoria</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock Actual</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Stock Minimo</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Estado</th>
              <th className="px-4 py-3 text-left text-xs font-medium text-gray-500 uppercase">Ubicacion</th>
            </tr>
          </thead>
          <tbody className="bg-white divide-y divide-gray-200">
            {filtrarInventario.map((item) => (
              <tr key={item.id} className="hover:bg-gray-50">
                <td className="px-4 py-3 text-sm font-medium text-gray-900">{item.producto}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{item.categoria}</td>
                <td className="px-4 py-3 text-sm font-semibold text-gray-900">{item.stock}</td>
                <td className="px-4 py-3 text-sm text-gray-500">{item.minimo}</td>
                <td className="px-4 py-3 text-sm">
                  <span className={`inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium ${obtenerColorEstado(item.estado)}`}>
                    {obtenerTextoEstado(item.estado)}
                  </span>
                </td>
                <td className="px-4 py-3 text-sm text-gray-500">{item.ubicacion}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Exportar */}
      <div className="mt-6 flex justify-end">
        <button className="bg-green-500 hover:bg-green-600 text-white px-4 py-2 rounded-lg font-medium transition duration-200">
          Exportar a Excel
        </button>
      </div>

      {filtrarInventario.length === 0 && (
        <div className="text-center py-8 text-gray-500">
          No se encontraron productos con los filtros aplicados
        </div>
      )}
    </div>
  );
};

export default ConsultaInventario;